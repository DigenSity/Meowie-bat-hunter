import os
import re
import random
import asyncio
import emoji
from dotenv import load_dotenv
from telethon import TelegramClient, events
from telethon.errors import FloodWaitError

load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
SESSION_PATH = os.getenv("SESSION_PATH", "bat_hunter.session")

# پارس کردن رشته‌های کامادار به لیست اعداد صحیح
def parse_id_list(env_var: str) -> list[int]:
    raw = os.getenv(env_var, "")
    return [int(x.strip()) for x in raw.split(",") if x.strip()]

TARGET_GROUP_IDS = parse_id_list("TARGET_GROUP_IDS")
GAME_BOT_IDS = parse_id_list("GAME_BOT_IDS")

IGNORED_EMOJIS = {"🦇", "🐱", "❗️", "🔺", "👑", "💰", "✍️", "🪙", "⏱", "✨"}

client = TelegramClient(SESSION_PATH, API_ID, API_HASH)

def extract_weapon_emoji(text: str) -> str:
    line_match = re.search(r"(?:وسیله|وسلیه)[^\n]*", text)
    if line_match:
        line_text = line_match.group(0)
        line_emojis = [
            item["emoji"]
            for item in emoji.emoji_list(line_text)
            if item["emoji"] not in IGNORED_EMOJIS
        ]
        if line_emojis:
            return line_emojis[0]

    all_emojis = [
        item["emoji"]
        for item in emoji.emoji_list(text)
        if item["emoji"] not in IGNORED_EMOJIS
    ]
    if all_emojis:
        return all_emojis[-1]

    return None

# Telethon خودش لیست چندتایی chats و from_users رو می‌پذیره
@client.on(events.NewMessage(chats=TARGET_GROUP_IDS, from_users=GAME_BOT_IDS))
async def handle_bat_spawn(event):
    raw_text = event.raw_text or ""

    if "خفاش" in raw_text and "شکار شد" not in raw_text:
        weapon = extract_weapon_emoji(raw_text)

        if not weapon:
            return

        delay = round(random.uniform(0.25, 0.60), 2)
        await asyncio.sleep(delay)

        try:
            await event.reply(weapon)
            print(f"[+] شکار شد: {weapon} | چت: {event.chat_id} | فرستنده: {event.sender_id} | لیتنسی: {delay}s")
        except FloodWaitError as e:
            print(f"[!] خطای فلوودویت: توقف به مدت {e.seconds} ثانیه")
            await asyncio.sleep(e.seconds)
        except Exception as e:
            print(f"[-] خطا در ارسال: {e}")

async def main():
    print(f"[*] فعال شد. مانیتور گروه‌ها: {TARGET_GROUP_IDS} | ربات‌ها: {GAME_BOT_IDS}")
    await client.run_until_disconnected()

with client:
    client.loop.run_until_complete(main())