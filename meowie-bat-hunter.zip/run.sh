#!/bin/bash
set -a
source .env
set +a

"$VENV_PATH/bin/python" main.py