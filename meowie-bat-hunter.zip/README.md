chmod +x run.sh
./run.sh
---

**مراحل راه‌اندازی استاندارد**

**۱. ساخت سشن اولیه (داخل ترمینال عادی یا tmux)**
یک‌بار اسکریپت را دستی ران کن تا لاگین شوی و فایل `.session` ساخته شود:

```bash
$VENV_PATH/bin/python main.py

```

شماره تلفن و کد تلگرام را وارد کن. به محض دیدن پیام `[*] فعال شد...` با `Ctrl+C` ببندش.

**۲. ساخت سرویس systemd**
فایل سرویس را ایجاد کن:

```bash
sudo nano /etc/systemd/system/bat-hunter.service

```

محتوا (مسیرها را مطابق سرور خودت تنظیم کن):

```ini
[Unit]
Description=Bat Hunter Userbot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/path/to/project
EnvironmentFile=/path/to/project/.env
ExecStart=/path/to/venv/bin/python /path/to/project/main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target

```

**۳. استارت و فعال‌سازی**

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now bat-hunter

```

**۴. مشاهده لاگ‌های زنده**

```bash
journalctl -u bat-hunter -f -o cat

```